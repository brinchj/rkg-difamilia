<h2><?php _e('404 - Page not found'); ?></h2>
<p>Oops ! I cannot found what you are looking for. Why don't you try again with a different keyword or look into my archives</p>