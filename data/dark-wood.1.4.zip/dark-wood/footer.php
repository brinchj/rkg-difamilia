<div id="footer">
Copyright &copy; 2009 <?php bloginfo('name'); ?>. All rights reserved.
</div>
<?php wp_footer(); ?>