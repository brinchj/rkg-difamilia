Theme Name: Wasteland
Theme URI: http://the-cloisters.net/themedemos/?SelectedTheme=Wasteland
Author: Mina (I'm Raimy at Wordpress.org)
Author URI: http://the-cloisters.net
Version: 1.3

This theme is under GPL License. (http://www.opensource.org/licenses/gpl-license.php).  There are no restrictions to the use of this theme.  I'd appreciate it if you left my link in the footer but I won't send the Theme Police 'round to your house if you don't.

Description: 5 Column (main content, 2 sidebars and 2 top sections), widget-ready fixed width theme in soothing Creme and Brown colors featuring an author box, author info page, gravatars and highlighted author comments in the comments section along with Custom Archives, Sitemap and full width No Sidebars page templates.  Tested in Firefox, Opera, Safari, IE6 and IE7. Compatible up to Wordpress 2.7.

INSTALLATION: 
1. Unzip and upload the directory to your wp-content/themes/directory.
2. Go to Admin >> Design and select the theme.
3. Go to your site to see the theme.

CHANGELOG:
Version 1.3 - Fixed a bug that caused the layout to break when using the search widget.
