<div id="area2">

<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(area2) ) : else : ?>           
         
		<?php get_calendar(); ?>        		
     	
<?php endif; ?>

</div>