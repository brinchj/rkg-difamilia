<div id="top">
 <div class="top-section">

        <div class="area extra">
		<?php include ('area1.php'); ?>		
	</div>	
	<div class="area">
		<?php include ('area2.php'); ?>		
	</div>        
  </div>
</div>