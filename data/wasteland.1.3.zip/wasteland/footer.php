<div id="footer">

<p><?php _e('Copyright',''); ?> &#169; <?php print(date(__('Y',''))); ?> <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> is Proudly Powered by <a href="http://wordpress.org">Wordpress</a>. Theme by <a href="http://www.the-cloisters.net">The Cloisters</a> 
&nbsp;</p>

</div>
</div></div>
<?php wp_footer(); ?>
</body>
</html>