<?php get_header(); ?>

<?php include('left_sidebar.php');?>

<div id="container">

<h2>I'm Sorry, This Page Does Not Exist :(</h2>

<p>You're receiving this error because the page you are looking for no longer exists on this website.</p> 

</div>

</div>

<?php include('right_sidebar.php');?>

<?php get_footer(); ?>