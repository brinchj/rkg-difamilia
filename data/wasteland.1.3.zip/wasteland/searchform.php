<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
<div>
	<div>
		<input type="text" class="txt" name="s" id="s" value="Type and hit enter to search" onfocus="if (this.value == 'Type and hit enter to search') {this.value = '';}" onblur="if (this.value == '') {this.value = 'Type and hit enter to search';}" />
	</div>
</div>
</form>