<div id="area1">

<?php if ( function_exists('dynamic_sidebar') && dynamic_sidebar(area1) ) : else : ?>
	        	
	<h2>Welcome To Our Site...</h2>
<p>Fusce sed justo. Vestibulum eget pede. Pellentesque venenatis nisl et nulla. Nulla malesuada tincidunt nunc. Praesent erat diam, sollicitudin nec, egestas a, tempor et, felis. Aliquam ante lectus, vehicula ac, commodo sed, luctus a, turpis. Aliquam vehicula quam porttitor felis. Quisque metus ante, molestie sit amet, adipiscing sed, vulputate scelerisque, arcu. Nunc suscipit sem e.</p>
     	
<?php endif; ?>

</div>